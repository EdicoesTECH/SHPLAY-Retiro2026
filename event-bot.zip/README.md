# 🎪 EventBot — App de Crachá para Eventos

App de chat com bot que solicita a foto do participante e gera automaticamente um crachá personalizado com a identidade visual do evento. Funciona 100% no navegador, sem servidor, ideal para GitHub Pages.

---

## 🚀 Como colocar no ar (passo a passo)

### 1. Faça o upload para o GitHub

1. Acesse [github.com](https://github.com) e crie um **novo repositório** (pode ser público)
2. Nome sugerido: `event-bot` ou o nome do seu evento
3. Faça upload de todos os arquivos desta pasta para o repositório

### 2. Ative o GitHub Pages

1. No repositório, vá em **Settings** → **Pages**
2. Em "Source", selecione **Deploy from a branch**
3. Selecione a branch `main` e a pasta `/ (root)`
4. Clique em **Save**
5. Em alguns minutos o site estará disponível em `https://seu-usuario.github.io/event-bot`

### 3. Aponte seu domínio personalizado

1. Em **Settings → Pages**, adicione seu domínio em "Custom domain"
2. No seu provedor de domínio (Registro.br, GoDaddy, etc.), crie os seguintes registros DNS:

   **Opção A — Subdomínio (ex: evento.seudominio.com.br)**
   ```
   Tipo: CNAME
   Nome: evento
   Valor: seu-usuario.github.io
   ```

   **Opção B — Domínio raiz (ex: seudominio.com.br)**
   ```
   Tipo: A    Valor: 185.199.108.153
   Tipo: A    Valor: 185.199.109.153
   Tipo: A    Valor: 185.199.110.153
   Tipo: A    Valor: 185.199.111.153
   ```

3. Aguarde até 24h para a propagação do DNS
4. Marque **Enforce HTTPS** depois que o DNS propagar

---

## ✏️ Como personalizar

### Mudar nome do evento, cores e mensagens

Edite o arquivo **`src/config.js`**:

```js
export const CONFIG = {
  eventName: 'MEU EVENTO',          // ← Mude aqui
  eventSubtitle: '2025 · Edição Especial',
  eventColor: '#7c5cfc',            // ← Cor principal (hex)
  eventColorLight: '#b28dff',       // ← Cor de destaque

  messages: {
    welcome: 'Olá! Bem-vindo ao *{eventName}*!...',  // ← Texto do bot
    // ...
  }
}
```

### Usar seu próprio template (design do evento)

A geração de crachá acontece no arquivo **`src/bot.js`** na função `generateBadge()`.

**Opção simples — usar um template PNG:**
1. Crie um PNG do seu crachá com uma área transparente onde a foto vai entrar
2. Salve como `public/template.png`
3. Na função `generateBadge()` em `src/bot.js`, adicione após o fundo:
   ```js
   const template = await loadImage('./public/template.png')
   ctx.drawImage(template, 0, 0, width, height)
   ```
4. Ajuste `photoX`, `photoY`, `photoSize` em `config.js` para que a foto se encaixe na área transparente

---

## 📁 Estrutura do projeto

```
event-bot/
├── index.html          ← Página principal
├── src/
│   ├── config.js       ← ⚙️  CONFIGURAÇÕES (edite aqui!)
│   ├── styles.css      ← Estilos visuais
│   ├── main.js         ← Ponto de entrada
│   ├── bot.js          ← Lógica do bot + geração do crachá
│   └── ui.js           ← Renderização do chat
├── public/
│   └── template.png    ← (opcional) Template do seu design
└── README.md
```

---

## 🛠️ Tecnologias usadas

- **HTML + CSS + JavaScript** puro (sem frameworks)
- **ES Modules** (import/export nativos do browser)
- **Canvas API** para composição da imagem
- **Web Share API** para compartilhamento nativo (mobile)
- **GitHub Pages** para hospedagem gratuita

---

## 💡 Dicas

- A foto é processada **100% no dispositivo do usuário** — nenhum dado é enviado para servidor
- Em celular, o botão "Compartilhar" usa o compartilhamento nativo do sistema operacional
- Para melhor resultado, oriente os participantes a usar fotos com boa iluminação e rosto visível
- Você pode testar localmente abrindo o `index.html` diretamente no navegador (Chrome/Edge recomendados)
